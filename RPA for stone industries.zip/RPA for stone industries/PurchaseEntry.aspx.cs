﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class PurchaseEntry : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblPurchaseEntry (PurchaseDate,SuppId,MatId,PurchaseQty,PurchaseRate,EmpId) VALUES ('" + txtPurchaseDate.Text + "','" + ddlSuppId.Text + "','" + ddlMatId.Text + "','" + txtPurchaseQty.Text + "','" + txtPurchaseRate.Text + "','" + ddlEmpId.Text + "')";
        }
        else
        {
            qry = "UPDATE tblPurchaseEntry SET PurchaseDate='" + txtPurchaseDate.Text + "',SuppId='" + ddlSuppId.SelectedValue + "',MatId='" + ddlMatId.SelectedValue + "',PurchaseQty='" + txtPurchaseQty.Text + "',PurchaseRate='" + txtPurchaseRate.Text + "',EmpId='" + ddlEmpId.SelectedValue + "' WHERE PurchaseId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";
    }
    protected void ClearAll()
    {
        txtPurchaseDate.Text = "";
        txtPurchaseQty.Text = "";
        txtPurchaseRate.Text = "";

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
    pnlView.Visible = true;
    pnlForm.Visible = false;
    FillGrid();
    }
    protected void FillGrid()
    {
        qry = "SELECT PurchaseId AS [ID],PurchaseDate AS [Purchase Date],SuppId AS [Supplier Id],MatId AS [Material Id],PurchaseQty AS [Purchase Quantity],PurchaseRate AS [Purchase Rate],EmpId AS [Employee Id] FROM tblPurchaseEntry";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblPurchaseEntry WHERE PurchaseId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
    pnlView.Visible = false;
pnlForm.Visible = true;
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblPurchaseEntry WHERE PurchaseId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtPurchaseDate.Text = dr.GetValue(1).ToString();
            ddlSuppId.Text = dr.GetValue(2).ToString();
            ddlMatId.Text = dr.GetValue(3).ToString();
            txtPurchaseQty.Text = dr.GetValue(4).ToString();
            txtPurchaseRate.Text = dr.GetValue(5).ToString();
            ddlEmpId.Text = dr.GetValue(6).ToString();

          

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd-MMM-yyyy");
            
        }
    }
}