﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class Product : System.Web.UI.Page
{
    String qry;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblProduct WHERE ProductId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblProduct (ProductName,Phase1Days,Phase1Qty,Phase2Days,Phase2Qty,Phase3Days,Phase3Qty) VALUES ('" + txtProductName.Text + "','" + txtPhase1Days.Text + "','" + txtPhase1Qty.Text + "','" + txtPhase2Days.Text + "','" + txtPhase2Qty.Text + "','" + txtPhase3Days.Text + "','" + txtPhase3Qty.Text + "')";
        }
        else
        {
            qry = "UPDATE tblProduct SET ProductName='" + txtProductName.Text + "',Phase1Days='" + txtPhase1Days.Text + "',Phase1Qty='" + txtPhase1Qty.Text + "',Phase2Days='" + txtPhase2Days.Text + "',Phase2Qty='" + txtPhase2Qty.Text + "',Phase3Days='" + txtPhase3Days.Text + "',Phase3Qty='" + txtPhase3Qty.Text + "' WHERE ProductId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";
    }
    protected void ClearAll()
    {
        txtProductName.Text = "";
        txtPhase1Days.Text = "";
        txtPhase1Qty.Text = "";
        txtPhase2Days.Text = "";
        txtPhase2Qty.Text = "";
        txtPhase3Days.Text = "";
        txtPhase3Qty.Text = "";

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();
    }
    protected void FillGrid()
    {
        qry = "SELECT ProductId AS [ID],ProductName AS [Product Name],Phase1Days,Phase1Qty,Phase2Days,Phase2Qty,Phase3Days,Phase3Qty FROM tblProduct";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        pnlView.Visible = false;
        pnlForm.Visible = true;
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblProduct WHERE ProductId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtProductName.Text = dr.GetValue(1).ToString();
            txtPhase1Days.Text = dr.GetValue(2).ToString();
            txtPhase1Qty.Text = dr.GetValue(3).ToString();
            txtPhase2Days.Text = dr.GetValue(4).ToString();
            txtPhase2Qty.Text = dr.GetValue(5).ToString();
            txtPhase3Days.Text = dr.GetValue(6).ToString();
            txtPhase3Qty.Text = dr.GetValue(7).ToString();

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
}