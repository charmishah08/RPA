﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["uname"].ToString() == "")
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["uname"].ToString() + " | " + Session["utype"].ToString();

                mnuAdministrator.Visible = false;
                mnuMarketingExecutive.Visible = false;
                mnuProductionManager.Visible = false;
                mnuSalesManager.Visible = false;

                mnuCustomer.Visible = false;

                if (Session["utype"].ToString() == "Administrator")
                {
                    mnuAdministrator.Visible = true;
                }
                else if (Session["utype"].ToString() == "Customer")
                {
                    mnuCustomer.Visible = true;
                }
                else if (Session["utype"].ToString() == "Marketing Executive")
                {
                    mnuMarketingExecutive.Visible = true;
                }
                else if (Session["utype"].ToString() == "Production Manager")
                {
                    mnuProductionManager.Visible = true;
                }
                else if (Session["utype"].ToString() == "Sales Manager")
                {
                    mnuSalesManager.Visible = true;
                }
            }
        }
    }
}
