﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class SalesEntry : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ClearAll()
    {
        txtSalesDate.Text = "";
        txtSalesQty.Text = "";
       

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblSalesEntry (SalesDate,CustId,SOId,ProductId,SalesQty,EmpId) VALUES ('" + txtSalesDate.Text + "','" + ddlCustId.Text + "','" + ddlSOId.Text + "','" + ddlProductId.Text + "','" + txtSalesQty.Text + "','" + ddlEmpId.Text + "')";
        }
        else
        {
            qry = "UPDATE tblSalesEntry SET SalesDate='" + txtSalesDate.Text + "',CustId='" + ddlCustId.Text + "',SOId='" + ddlSOId.Text + "',ProductId='" + ddlProductId.Text + "',SalesQty='" + txtSalesQty.Text + "', EmpId='" + ddlEmpId.Text + "' WHERE SalesId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblSalesEntry WHERE SalesId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        PnlView.Visible = true;
        PnlForm.Visible = false;
        FillGrid();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        PnlView.Visible = false;
        PnlForm.Visible = true;
    }

    protected void FillGrid()
    {
        qry = "SELECT * FROM tblSalesEntry";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblSalesEntry WHERE SalesId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtSalesDate.Text = dr.GetValue(1).ToString();
            ddlCustId.SelectedValue = dr.GetValue(2).ToString();
            ddlSOId.SelectedValue = dr.GetValue(3).ToString();
            ddlProductId.SelectedValue = dr.GetValue(4).ToString();
            txtSalesQty.Text = dr.GetValue(5).ToString();
            ddlEmpId.SelectedValue = dr.GetValue(6).ToString();


            PnlView.Visible = false;
            PnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }


    protected void GridView1_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd-MMM-yyyy");
            
        }
    }
}