﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class SupplierInfo : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void ClearAll()
    {
        txtSuppCompanyName.Text = "";
        txtSuppPersonName.Text = "";
        txtSuppEmail.Text = "";
        txtSuppMob.Text = "";
        txtSuppAdd.Text = "";
        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblSupplierInfo (SuppCompanyName,SuppPersonName,SuppEmail,SuppMobile,SuppAdd) VALUES ('" + txtSuppCompanyName.Text + "','" + txtSuppPersonName.Text + "','" + txtSuppEmail.Text + "','" + txtSuppMob.Text + "','" + txtSuppAdd.Text + "')";
        }
        else
        {
            qry = "UPDATE tblSupplierInfo SET SuppCompanyName='" + txtSuppCompanyName.Text + "',SuppPersonName='" + txtSuppPersonName.Text + "',SuppEmail='" + txtSuppEmail.Text + "',SuppMobile='" + txtSuppMob.Text + "',SuppAdd='" + txtSuppAdd.Text + "' WHERE SuppId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblSupplierInfo WHERE SuppId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void  btnReset_Click(object sender, EventArgs e)
    {
         ClearAll();
    }
    protected void  btnClose_Click(object sender, EventArgs e)
    {
         Response.Redirect("Dashboard.aspx");
    }
    protected void  btnView_Click(object sender, EventArgs e)
    {
        PnlView.Visible = true;
        PnlForm.Visible = false;
        FillGrid();
    }
    protected void  btnBack_Click(object sender, EventArgs e)
    {
        PnlView.Visible = false;
        PnlForm.Visible = true;
    }

    protected void FillGrid()
    {
        qry = "SELECT SuppId AS [ID],SuppCompanyName AS [Company Name],SuppPersonName AS [Person Name],SuppEmail AS [Email],SuppMobile AS [Mobile],SuppAdd AS [Address] FROM tblSupplierInfo";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblSupplierInfo WHERE SuppId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtSuppCompanyName.Text = dr.GetValue(1).ToString();
            txtSuppPersonName.Text = dr.GetValue(2).ToString();
            txtSuppEmail.Text = dr.GetValue(3).ToString();
            txtSuppMob.Text = dr.GetValue(4).ToString();
            txtSuppAdd.Text = dr.GetValue(5).ToString();

            PnlView.Visible = false;
            PnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
}