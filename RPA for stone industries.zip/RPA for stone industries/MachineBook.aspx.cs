﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;


public partial class MachineBook : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblMachineBook (MachId,SOId,FromDate,ToDate) VALUES ('" + ddlMachId.SelectedValue + "','" + ddlSOId.SelectedValue + "','" + txtFromDate.Text + "','" + txtToDate.Text + "')";
        }
        else
        {
            qry = "UPDATE tblMachineBook SET MachId='" + ddlMachId.SelectedValue + "',SOId='" + ddlSOId.SelectedValue + "',FromDate='" + txtFromDate.Text + "',ToDate='" + txtToDate.Text + "' WHERE MBId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";
    }
    protected void ClearAll()
    {
        txtFromDate.Text = "";
        txtToDate.Text = "";
        ddlMachId.SelectedIndex = 0;
        ddlSOId.SelectedIndex = 0;


        lblMsg.Text = "";

        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
        btnSubmit.Visible = false;
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();
    }
    protected void FillGrid()
    {
        qry = "SELECT MBId AS [ID],MachId AS [Machine Id],SOId AS [Sales Order Id],FromDate AS [From Date],ToDate AS [To Date] FROM tblMachineBook";

        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {

            qry = "DELETE FROM tblMachineBook WHERE MBId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        qry = "SELECT * FROM tblMachineBook WHERE  MBId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            ddlMachId.SelectedValue = dr.GetValue(1).ToString();
            ddlSOId.SelectedValue = dr.GetValue(2).ToString();
            txtFromDate.Text = Convert.ToDateTime(dr.GetValue(3).ToString()).ToString("dd-MMM-yyyy");
            txtToDate.Text = Convert.ToDateTime(dr.GetValue(4).ToString()).ToString("dd-MMM-yyyy");

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        pnlView.Visible = false;
        pnlForm.Visible = true;
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[4].Text = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd-MMM-yyyy");
            e.Row.Cells[5].Text = Convert.ToDateTime(e.Row.Cells[5].Text).ToString("dd-MMM-yyyy");
        }
    }
    protected void btnCheckDates_Click(object sender, EventArgs e)
    {
        //FINDING NON-RESERVE DATE

        DateTime fromdt = Convert.ToDateTime(txtFromDate.Text);
        DateTime todt = Convert.ToDateTime(txtToDate.Text);

        if (fromdt <= DateTime.Now || todt <= DateTime.Now)
        {
            lblMsg.Text = "Past date cannot selected";
            btnSubmit.Visible = false;
        }
        else
        {
            String reply = "";
            String fd = fromdt.ToString("dd-MMM-yyyy");
            String td = todt.ToString("dd-MMM-yyyy");

            while (fromdt <= todt)
            {

                qry = "SELECT * FROM tblMachineBook WHERE MachId='" + ddlMachId.SelectedValue + "' AND (FromDate<='" + fd + "' AND ToDate>='" + fd + "')";

                SqlDataReader dr = rpa_class.getrecord(qry);
                if (dr.Read())
                {
                    reply = "The Machine " + ddlMachId.SelectedItem.Text + "  is already booked for the period from " + Convert.ToDateTime(dr.GetValue(3).ToString()).ToString("dd-MMM-yyyy") + " to " + Convert.ToDateTime(dr.GetValue(4).ToString()).ToString("dd-MMM-yyyy");
                    btnSubmit.Visible = false;

                    fromdt = todt;
                }
                else
                {
                    if (reply == "")
                    {
                        reply = "You can book for this period";
                        btnSubmit.Visible = true;
                    }
                }
                dr.Close();
                fromdt = fromdt.AddDays(1);
            }

            lblMsg.Text = reply;
        }
    }
}
