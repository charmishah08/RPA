﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class ChangePassword : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblEmployeeInfo WHERE EmpId=" + Session["uid"].ToString() + " AND LoginPassword='" + txtLoginPassword.Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            dr.Close();
            qry = "UPDATE tblEmployeeInfo SET LoginPassword='" + txtNewPassword.Text + "' WHERE EmpId=" + Session["uid"].ToString();
            int i = rpa_class.setRecord(qry);

            lblMsg.Text = "Your password has been changed.";
        }
        else
        {
            dr.Close();
            lblMsg.Text = "Your current password is invalid.";
        }
    }
}