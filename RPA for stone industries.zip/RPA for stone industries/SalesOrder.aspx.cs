﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SalesOrder : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtSODate.Text = DateTime.Now.ToString("dd-MMM-yyyy");

        }
    }

    protected void ClearAll()
    {
        txtSODate.Text = DateTime.Now.ToString("dd-MMM-yyyy");
        txtProdQty.Text = "";
        txtStartDate.Text = "";
        txtEndDate.Text = "";

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        DateTime fromdt = Convert.ToDateTime(txtStartDate.Text);
        DateTime todt = Convert.ToDateTime(txtEndDate.Text);

        if (fromdt >= DateTime.Now || todt >= DateTime.Now)
        {
            if (btnSubmit.Text == "Submit")
            {
                qry = "INSERT INTO tblSalesOrder (SODate,CustId,ProductId,ProdQty,EmpId,StartDate,EndDate) VALUES ('" + txtSODate.Text + "','" + ddlCustId.Text + "','" + ddlProductId.Text + "','" + txtProdQty.Text + "','" + ddlEmpId.Text + "','" + txtStartDate.Text + "','" + txtEndDate.Text + "')";
            }
            else
            {
                qry = "UPDATE tblSalesOrder SET SODate='" + txtSODate.Text + "',CustId='" + ddlCustId.Text + "',ProductId='" + ddlProductId.Text + "',ProdQty='" + txtProdQty.Text + "',EmpId='" + ddlEmpId.Text + "',StartDate='" + txtStartDate.Text + "',EndDate='" + txtEndDate.Text + "' WHERE SOId='" + GridView1.SelectedRow.Cells[1].Text + "'";
            }

            int i = rpa_class.setRecord(qry);

            //img upload code
            int soid = 0;
            if (btnSubmit.Text == "Submit")
            {
                qry = "SELECT MAX(SOId) FROM tblSalesOrder";
                SqlDataReader dr = rpa_class.getrecord(qry);

                if (dr.Read())
                {
                    soid = Convert.ToInt32(dr.GetValue(0).ToString());
                }
            }
            else
            {
                soid = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);
            }

            String fileExt = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (fileExt == ".jpeg" || fileExt == ".jpg")
            {
                FileUpload1.SaveAs(Server.MapPath(".") + "//prod-img//" + soid + ".jpg");
            }
            //img upload code

            ClearAll();
            lblMsg.Text = "Record Submitted Successfully.";
        }
        else
        {
            lblMsg.Text = "Cannot select the previous days";
        }

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblSalesOrder WHERE SOId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        PnlView.Visible = true;
        PnlForm.Visible = false;
        FillGrid();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        PnlView.Visible = false;
        PnlForm.Visible = true;
    }

    protected void FillGrid()
    {
        qry = "SELECT SOId AS [ID],SODate AS [Date],CustId AS [Customer Id],ProductId AS [Product Id],ProdQty AS [Product Quantity],EmpId AS [Employee Id],StartDate AS [Start Date],EndDate AS [End Date] FROM tblSalesOrder";

        if (Session["utype"].ToString() == "Customer")
        {
            qry = "SELECT SOId AS [ID],SODate AS [Date],CustId AS [Customer Id],ProductId AS [Product Id],ProdQty AS [Product Quantity],EmpId AS [Employee Id],StartDate AS [Start Date],EndDate AS [End Date] FROM tblSalesOrder WHERE CustId=" + Session["uid"].ToString();
            GridView1.Enabled = true;
        }

        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblSalesOrder WHERE SOId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtSODate.Text = dr.GetValue(1).ToString(); ;
            ddlCustId.SelectedValue = dr.GetValue(2).ToString(); ;
            ddlProductId.SelectedValue = dr.GetValue(3).ToString(); ; 
            txtProdQty.Text = dr.GetValue(4).ToString(); ;
            ddlEmpId.SelectedValue = dr.GetValue(5).ToString(); ;
            txtStartDate.Text = dr.GetValue(6).ToString(); ;
            txtEndDate.Text = dr.GetValue(7).ToString(); ;

            imgProduct.ImageUrl = "prod-img/" + dr.GetValue(0).ToString() + ".jpg";

            PnlView.Visible = false;
            PnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
    protected void ddlEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd-MMM-yyyy");
            e.Row.Cells[7].Text = Convert.ToDateTime(e.Row.Cells[7].Text).ToString("dd-MMM-yyyy");
            e.Row.Cells[8].Text = Convert.ToDateTime(e.Row.Cells[8].Text).ToString("dd-MMM-yyyy");
        }
    }
}