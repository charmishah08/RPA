﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class CustomerInfo : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblCustomerInfo (CustCompanyName,CustPersonName,CustEmail,CustMob,CustAdd) VALUES ('" +  txtCompany.Text + "','" + txtPerson.Text+ "','" + txtEmail.Text+ "','" + txtMobile.Text+ "','" + txtAddress.Text+ "')";
        }
        else
        {
            qry = "UPDATE tblCustomerInfo SET CustCompanyName='" + txtCompany.Text + "',CustPersonName ='" + txtPerson.Text+"',CustEmail ='"+ txtEmail.Text+"',CustMob ='"+ txtMobile.Text+"',CustAdd ='"+ txtAddress.Text +"'WHERE CustId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();

        lblMsg.Text = "Record Submitted Successfully.";
    }

    protected void ClearAll()
    {
        txtCompany.Text = "";
        txtPerson.Text = "";
        txtEmail.Text = "";
        txtMobile.Text = "";
        txtAddress.Text = "";

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;

    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();

    }

    protected void FillGrid()
    {
         qry = "SELECT CustID AS [ID],CustCompanyName AS [Comapny Name],CustPersonName AS [Name],CustEmail AS [Email],CustMob AS [Mobile],CustAdd AS [Address] FROM tblCustomerInfo";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        pnlView.Visible = false;
        pnlForm.Visible = true;
    }

    protected void btnClose_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnView_Click1(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();
    }
    protected void  btnBack_Click1(object sender, EventArgs e)
    {
             pnlView.Visible = false;
            pnlForm.Visible = true;
    }
    protected void btnDelete_Click1(object sender, EventArgs e)
    {
        try
        {
            qry = "DELETE FROM tblCustomerInfo WHERE CustId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }

        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click1(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblCustomerInfo WHERE CustId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtCompany.Text = dr.GetValue(1).ToString();
            txtPerson.Text = dr.GetValue(2).ToString();
            txtEmail.Text = dr.GetValue(3).ToString();
            txtMobile.Text = dr.GetValue(4).ToString();
            txtAddress.Text = dr.GetValue(5).ToString();

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
}

