﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
public partial class Dashboard : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["utype"].ToString() == "Production Manager")
            {
                pnlPM.Visible = true;

                txtDate.Text = DateTime.Now.ToString("dd-MMM-yyyy");

                qry = "SELECT * FROM viewMachineBook WHERE FromDate<='" + DateTime.Now.ToString() + "' AND ToDate>='" + DateTime.Now.ToString() + "'";
                GridView1.DataSource = rpa_class.getrecord(qry);
                GridView1.DataBind();
            }
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        qry = "SELECT * FROM viewMachineBook WHERE FromDate<='" + txtDate.Text + "' AND ToDate>='" + txtDate.Text + "'";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[4].Text = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd-MMM-yyyy");
            e.Row.Cells[5].Text = Convert.ToDateTime(e.Row.Cells[5].Text).ToString("dd-MMM-yyyy");
        }
    }
}