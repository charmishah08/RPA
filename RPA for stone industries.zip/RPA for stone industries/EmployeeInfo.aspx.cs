﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class EmployeeInfo : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        String gender = "M";
        if (rbtnFemale.Checked) gender = "F";

        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblEmployeeInfo (EmplFName,EmplMName,EmplLName,DeptId,LoginEmail,LoginPassword,EmpMob,EmpGender,EmpAdd) VALUES ('" + txtFName.Text +"','" + txtMName.Text +"','" + txtLName.Text +"','" + ddlDeptId.SelectedValue +"','" + txtLoginEmail.Text +"','" + txtLoginPassword.Text +"','" + txtEmpMob.Text +"','" + gender +"','" + txtEmpAdd.Text +"')";
        }
        else
        {
            qry = "UPDATE tblEmployeeInfo SET EmplFName='" + txtFName.Text + "',EmplMName='" + txtMName.Text + "',EmplLName='" + txtLName.Text + "',DeptId='" + ddlDeptId.SelectedValue + "',LoginEmail='" + txtLoginEmail.Text + "',LoginPassword='" + txtLoginPassword.Text + "',EmpMob='" + txtEmpMob.Text + "',EmpGender='" + gender + "',EmpAdd='" + txtEmpAdd.Text + "' WHERE EmpId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";
    }
    protected void ClearAll()
    {
        txtEmpAdd.Text = "";
        txtEmpMob.Text = "";
        txtFName.Text = "";
        txtLName.Text = "";
        txtLoginEmail.Text = "";
        txtMName.Text = "";
        ddlDeptId.SelectedIndex = 0;

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();
    }
    protected void FillGrid()
    {
        qry = "SELECT EmpID AS [ID],EmplFName AS [First Name],EmplMName AS [Middle Name],EmplLName AS [Last Name],DeptId AS [Department Id],LoginEmail AS [Email],LoginPassword AS [password],EmpMob AS [Mobile No],EmpGender AS [Gender],EmpAdd AS [Address] FROM tblEmployeeInfo";

        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            qry = "DELETE FROM tblEmployeeInfo WHERE EmpId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        pnlView.Visible = false;
        pnlForm.Visible = true;
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblEmployeeInfo WHERE EmpId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtFName.Text = dr.GetValue(1).ToString();
            txtMName.Text = dr.GetValue(2).ToString();
            txtLName.Text = dr.GetValue(3).ToString();
            ddlDeptId.SelectedValue = dr.GetValue(4).ToString();
            txtLoginEmail.Text = dr.GetValue(5).ToString();
            txtLoginPassword.Text = dr.GetValue(6).ToString();
            txtEmpMob.Text = dr.GetValue(7).ToString();

            if (dr.GetValue(8).ToString() == "M")
            {
                rbtnMale.Checked = true;
                rbtnFemale.Checked = false;
            }
            else
            {
                rbtnMale.Checked = false;
                rbtnFemale.Checked = true;
            }

            txtEmpAdd.Text = dr.GetValue(9).ToString();

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
}