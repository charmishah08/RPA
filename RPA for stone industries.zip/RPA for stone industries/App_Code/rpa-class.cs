﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public class rpa_class
{
    public static SqlDataReader getrecord(String qry)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rpa-conn"].ConnectionString.ToString());
        conn.Open();
        SqlCommand cmd = new SqlCommand(qry, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        return dr;
    }
    public static int setRecord(String qry)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rpa-conn"].ConnectionString.ToString());
        conn.Open();

        SqlCommand cmd = new SqlCommand(qry, conn);
        int i = cmd.ExecuteNonQuery();
        conn.Close();

        return i;
    }
}