﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class Machinery : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ClearAll()
    {
        txtMachName.Text = "";
       
        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblMachinery (MachName,PhaseNo) VALUES ('" + txtMachName.Text + "','" +ddlPhaseNo.SelectedValue + "')";
        }
        else
        {
            qry = "UPDATE tblMachinery SET MachName='" + txtMachName.Text + "',PhaseNo='" + ddlPhaseNo.SelectedValue + "' WHERE MachId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {

            qry = "DELETE FROM tblMachinery WHERE MachId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        pnlView.Visible = true;
        pnlForm.Visible = false;
        FillGrid();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        pnlView.Visible = false;
        pnlForm.Visible = true;
    }

    protected void FillGrid()
    {
        qry = "SELECT MachId AS [ID],MachName AS [Machine Name],PhaseNo AS [Phase Number] FROM tblMachinery";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblMachinery WHERE MachId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtMachName.Text = dr.GetValue(1).ToString();
            ddlPhaseNo.SelectedValue = dr.GetValue(2).ToString();
        

            pnlView.Visible = false;
            pnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
}