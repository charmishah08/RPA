﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data;
using System.Data.SqlClient;

using System.Collections.Generic;
using System.Net;
using System.Net.Mail;

public partial class forgetpswd : System.Web.UI.Page
{
    String qry;
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblEmployeeInfo WHERE LoginEmail='" + txtEmail.Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            String pwd = dr.GetValue(6).ToString();

            //for sedning email code starts here
            NetworkCredential loginInfo = new NetworkCredential("imagesoftware.student@gmail.com", "AbCd123456789");
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("imagesoftware.student@gmail.com");
            msg.To.Add(new MailAddress(txtEmail.Text));
            msg.Subject = "Inquiry about Forget Password";
            msg.Body = "Your password is " + pwd;
            msg.IsBodyHtml = true;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = loginInfo;
            client.Send(msg);
            //for sending email ends here

            lblMsg.Text = "Your password has been sent to your Email ID.";
        }
        else
        {
            lblMsg.Text = "The user does not exist.";
        }
        dr.Close();
        
    }
}