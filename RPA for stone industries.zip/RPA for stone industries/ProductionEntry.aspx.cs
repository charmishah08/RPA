﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class ProductionEntry : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ClearAll()
    {
        txtProdDate.Text = "";
        txtProdQty.Text = "";

        lblMsg.Text = "";
        btnSubmit.Text = "Submit";
        btnDelete.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (btnSubmit.Text == "Submit")
        {
            qry = "INSERT INTO tblProductionEntry (ProdDate,SOId,ProductId,ProdQty,EmpId) VALUES ('" + txtProdDate.Text + "','" + ddlSOId.SelectedValue + "','" + ddlProductId.SelectedValue + "','" + txtProdQty.Text + "','" + ddlEmpId.SelectedValue + "')";
        }
        else
        {
            qry = "UPDATE tblProductionEntry SET ProdDate='" + txtProdDate.Text + "',SOId='" + ddlSOId.SelectedValue + "',ProductId='" + ddlProductId.SelectedValue + "',ProdQty='" + txtProdQty.Text + "',EmpId='" + ddlEmpId.SelectedValue + "' WHERE ProdId='" + GridView1.SelectedRow.Cells[1].Text + "'";
        }

        int i = rpa_class.setRecord(qry);
        ClearAll();
        lblMsg.Text = "Record Submitted Successfully.";

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            qry = "DELETE FROM tblProductionEntry WHERE ProdId='" + GridView1.SelectedRow.Cells[1].Text + "'";

            int i = rpa_class.setRecord(qry);
            ClearAll();
            lblMsg.Text = "Record Deleted Successfully.";
        }
        catch
        {
            lblMsg.Text = "Value is present in child table, so cannot delete the record";
        }
        finally { }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearAll();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        PnlView.Visible = true;
        PnlForm.Visible = false;
        FillGrid();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        PnlView.Visible = false;
        PnlForm.Visible = true;
    }

    protected void FillGrid()
    {
        qry = "SELECT ProdId AS [ID],ProdDate AS [Date],SOId AS [Sales Order Id],ProductId,ProdQty AS [Quantity],EmpId AS [Employee Id] FROM tblProductionEntry";
        GridView1.DataSource = rpa_class.getrecord(qry);
        GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblProductionEntry WHERE ProdId='" + GridView1.SelectedRow.Cells[1].Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            txtProdDate.Text = dr.GetValue(1).ToString();
            ddlSOId.SelectedValue = dr.GetValue(2).ToString();
            ddlProductId.SelectedValue = dr.GetValue(3).ToString();
            txtProdQty.Text = dr.GetValue(4).ToString();
            ddlEmpId.SelectedValue = dr.GetValue(5).ToString();

            PnlView.Visible = false;
            PnlForm.Visible = true;
            btnSubmit.Text = "Update";
            btnDelete.Visible = true;
        }
        dr.Close();
    }
    protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = Convert.ToDateTime(e.Row.Cells[2].Text).ToString("dd-MMM-yyyy");

        }
    }
}