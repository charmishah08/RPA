﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;


using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
public partial class _Default : System.Web.UI.Page
{
    String qry;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["uid"] = "";
            Session["uname"] = "";
            Session["utype"] = "";
        }
    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlUsertype.SelectedValue == "Employee")
            {
                qry = "SELECT * FROM viewEmployeeInfo WHERE LoginEmail='" + txtUsername.Text + "' AND LoginPassword='" + txtPassword.Text + "'";
            }
            else if (ddlUsertype.SelectedValue == "Customer")
            {
                qry = "SELECT * FROM tblCustomerInfo WHERE CustEmail='" + txtUsername.Text + "' AND CustPassword='" + txtPassword.Text + "'";
            }
            else
            {
                qry = "";
            }

            SqlDataReader dr = rpa_class.getrecord(qry);
            if (dr.Read() == true)
            {
                Session["uid"] = dr.GetValue(0).ToString();
                Session["uname"] = dr.GetValue(1).ToString();
                if (ddlUsertype.SelectedValue == "Customer")
                {
                    Session["utype"] = "Customer";
                }
                else
                {
                    Session["utype"] = dr.GetValue(5).ToString();
                }

                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                Response.Redirect("Default.aspx#price");
                lblMessage.Text = "Email ID or Password Invalid";
            }
            dr.Close();
        }
        catch
        {
            lblMessage.Text = "Please select all the values properly";
        }
        finally { }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx#registration");
    }

    protected void btnRegisterCustomer_Click(object sender, EventArgs e)
    {
        qry = "INSERT INTO tblCustomerInfo (CustCompanyName,CustPersonName,CustEmail,CustPassword,CustMob,CustAdd) VALUES ('" +  txtCompany.Text + "','" + txtPerson.Text+ "','" + txtEmail.Text+ "','"+ txtCustPassword.Text +"','" + txtMobile.Text+ "','" + txtAddress.Text+ "')";
        int i = rpa_class.setRecord(qry);
        lblMsg.Text = "Record Submitted Successfully.";
    }
    protected void txtCuxPassword_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnForgetSubmit_Click(object sender, EventArgs e)
    {
        qry = "SELECT * FROM tblEmployeeInfo WHERE LoginEmail='" + txtFEmail.Text + "'";

        SqlDataReader dr = rpa_class.getrecord(qry);
        if (dr.Read())
        {
            String pwd = dr.GetValue(6).ToString();

            //for sedning email code starts here
            NetworkCredential loginInfo = new NetworkCredential("imagesoftware.student@gmail.com", "AbCd123456789");
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("imagesoftware.student@gmail.com");
            msg.To.Add(new MailAddress(txtFEmail.Text));
            msg.Subject = "Inquiry about Forget Password";
            msg.Body = "Your password is " + pwd;
            msg.IsBodyHtml = true;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = loginInfo;
            client.Send(msg);
            //for sending email ends here

            lblFMsg.Text = "Your password has been sent to your Email ID.";
        }
        else
        {
            lblFMsg.Text = "The user does not exist.";
        }
        dr.Close();
    }
}